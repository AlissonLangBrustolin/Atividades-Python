from Desenvolvedor_Junior import Desenvolvedor_Junior



junior = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', junior)
    else:
        junior = Desenvolvedor_Junior(input("Digite seu nome: "), input("Digite sua cidade: "), input("Insira seu salário: "), input("Insira sua formação: "), input("Insira seu Cpf: "), input("Insira sua Identificação: "))
    junior.append(vars(junior))
