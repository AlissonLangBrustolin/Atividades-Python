class Loja_Computador:
    def __init__(self, nome):
        self.nome = nome
        