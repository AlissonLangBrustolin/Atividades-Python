class Desenvolvedor_Senior:
    def __init__(self, nome, cidade, salário, formação, Cpf, identificação_empresa):
        self.nome = nome
        self.cidade = cidade
        self.salário = salário
        self.formação = formação
        self.Cpf= Cpf
        self.identificação_empresa = identificação_empresa