class Cadastro_Curso:
    def __init__(self, nome_curso, período):
        self.nome_curso = nome_curso
        self.período = período