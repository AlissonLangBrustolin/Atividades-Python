from Cadastro_Curso import Cadastro_Curso



cursos = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', cursos)
    else:
        curso = Cadastro_Curso(input("Digite o nome do curso: "), input("Digite seu período: "))
        cursos.append(vars(curso))
