class Cadastro_Professor:
    def __init__(self, nome, cidade , salário, matricula):
        self.nome = nome
        self.cidade = cidade
        self.salário = salário
        self.matricula = matricula