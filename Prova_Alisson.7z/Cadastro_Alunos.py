class Cadastro_Alunos:
    def __init__(self, nome, cidade , renda, curso, matricula):
        self.nome = nome
        self.cidade = cidade
        self.renda = renda
        self.curso = curso
        self.matricula = matricula