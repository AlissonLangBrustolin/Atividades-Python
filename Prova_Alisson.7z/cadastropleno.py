from Desenvolvedor_Pleno import Desenvolvedor_Pleno



pleno = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', pleno)
    else:
        pleno = Desenvolvedor_Pleno(input("Digite seu nome: "), input("Digite sua cidade: "), input("Insira seu salário: "), input("Insira sua formação: "), input("Insira seu Cpf: "), input("Insira sua Identificação: "))
    pleno.append(vars(pleno))
