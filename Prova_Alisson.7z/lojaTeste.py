from Loja_Computador import Loja_Computador

peça_0 = Loja_Computador("Placa de Vídeo ")
peça_1 = Loja_Computador("Placa de Som ")
peça_2 = Loja_Computador("Caixa de som pra PC")
peça_3 = Loja_Computador("Processador")
peça_4 = Loja_Computador("Placa-Mãe")
peça_5 = Loja_Computador("Memória RAM")
peça_6 = Loja_Computador("Cooler PC")
peça_7 = Loja_Computador("Gabinete PC")
peça_8 = Loja_Computador("Gabinete Gamer")
peça_9 = Loja_Computador("Webcam")


print("Bem-vindo(a)! Escolha uma peça do computador da loja que deseja adquirir")
cliente = input("Digite seu nome para começarmos: ")
print(cliente, "Temos 10 opções de peças de computador  para você escolher: ",
"\n 0 - ", peça_0.nome, "\n 1 - ", peça_1.nome,"\n 2 -", peça_2.nome,"\n 3 -", peça_3.nome, "\n 4 - ", peça_4.nome,"\n 5 - ", peça_5.nome, "\n 6 - ", peça_6.nome,"\n 7 -", peça_7.nome,"\n 8 -", peça_8.nome, "\n 9 - ", peça_9.nome)

selecao = int(input("Selecione o número da peça do computador que lhe interessa: "))

lista_peças = [peça_0, peça_1, peça_2, peça_3, peça_4,peça_5,peça_6,peça_7,peça_8,peça_9]

opcao_sel = int(selecao)

for opcao in lista_peças:
    if opcao_sel >= 11 :
        print("Essa opção não está incluida na nossa loja de peça para computadores")
        break
    if opcao_sel <= 7:
        print(cliente, "sua peça de computador escolhida foi ", lista_peças[opcao_sel].nome)
        print("Obrigado, volte sempre")
        break