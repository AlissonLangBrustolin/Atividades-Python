from Profissional_Infraestrutura import Profissional_Infraestrutura



profissional = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', profissional)
    else:
        profissional = Profissional_Infraestrutura(input("Digite seu nome: "), input("Digite sua cidade: "), input("Insira seu salário: "), input("Insira sua formação: "), input("Insira seu Cpf: "), input("Insira sua Identificação: "))
    profissional.append(vars(profissional))
