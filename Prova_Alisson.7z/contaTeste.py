from Conta import Conta

contaAlisson = Conta('836-9', 'AlissonLang', 150.0, 1800.0)
print(vars(contaAlisson))
contaAlisson.deposita(90.0)
contaAlisson.extrato()
print(vars(contaAlisson))