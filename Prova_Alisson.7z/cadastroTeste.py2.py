from Cadastro_Professor import Cadastro_Professor



professores = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', professores)
    else:
        professor = Cadastro_Professor(input("Digite seu nome: "), input("Digite sua cidade: "), input("Insira seu salário: "), input("Digite sua matricula: "))
        professores.append(vars(professor))
