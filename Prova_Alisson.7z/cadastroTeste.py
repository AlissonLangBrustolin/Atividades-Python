from Cadastro_Alunos import Cadastro_Alunos



alunos = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', alunos)
    else:
        aluno = Cadastro_Alunos(input("Digite seu nome: "), input("Digite seu cidade: "), input("Insira seu renda: "), input("Insira seu curso: "), input("Insira sua matricula: "))
        alunos.append(vars(aluno))
