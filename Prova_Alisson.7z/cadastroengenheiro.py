from Engenheiro_Software import Engenheiro_Software



engenheiro = []
continuar = ''
while continuar != 'fim':
    continuar = str(input('Insira [fim] para finalizar o cadastro: '))

    if str(continuar) == 'fim':
        print('Dado de registros:', engenheiro)
    else:
        engenheiro = Engenheiro_Software(input("Digite seu nome: "), input("Digite sua cidade: "), input("Insira seu salário: "), input("Insira sua formação: "), input("Insira seu Cpf: "), input("Insira sua Identificação: "))
    engenheiro.append(vars(engenheiro))
